const timeDisplay = document.getElementById('time-display');
const startBtn = document.getElementById('start-btn');
const resetBtn = document.getElementById('reset-btn');
const clearStatsBtn = document.getElementById('clear-stats-btn');
const totalStats = document.getElementById('total-stats');
const pomoStatusText = document.getElementById('pomo-status');
const streakContainer = document.getElementById('streak-container');
const audioMasterBtn = document.getElementById('audio-master-btn');
const sliders = document.querySelectorAll('input[type="range"]');
const volLabels = [document.getElementById('vol-val-1'), document.getElementById('vol-val-2')];
const todoInput = document.getElementById('todo-input');
const addTodoBtn = document.getElementById('add-todo-btn');
const todoList = document.getElementById('todo-list');
const todoCounter = document.getElementById('todo-counter');

// Radio UI Elements
const radioPlayBtn = document.getElementById('radio-play-btn');
const radioIcon = document.getElementById('radio-icon');
const radioSlider = document.getElementById('radio-slider');
const radioVolVal = document.getElementById('radio-vol-val');

// Theme Toggle Registry Elements
const themeToggleBtn = document.getElementById('theme-toggle');
const themeIcon = document.getElementById('theme-icon');
const mainCard = document.getElementById('main-card');

let timerInterval = null;
let isTimerRunning = false;
let currentMode = 'focus'; 
let timeLeft = 25 * 60;
let totalSecondsStudied = parseInt(localStorage.getItem('secondsStudied')) || 0;
let completedSessionsCount = parseInt(localStorage.getItem('sessionsCount')) || 0;
let tasks = JSON.parse(localStorage.getItem('todoTasks')) || [];

// --- THEME SWAP LOGIC SYSTEM ---
let currentTheme = localStorage.getItem('theme-mode') || 'light';

function applyTheme(theme) {
    if (theme === 'dark') {
        document.body.className = "min-h-screen flex items-center justify-center antialiased p-6 relative overflow-hidden select-none bg-[#0a0a0c]";
        mainCard.className = "w-full max-w-5xl bg-black/40 backdrop-blur-3xl rounded-[32px] p-12 shadow-[0_30px_80px_rgba(0,0,0,0.4)] border border-white/5 grid grid-cols-1 md:grid-cols-5 gap-16 relative z-10 transition-all duration-500";
        themeIcon.innerHTML = `<path d="M12 7c-2.76 0-5 2.24-5 5s2.24 5 5 5 5-2.24 5-5-2.24-5-5-5zM2 13h2c.55 0 1-.45 1-1s-.45-1-1-1H2c-.55 0-1 .45-1 1s.45 1 1 1zm18 0h2c.55 0 1-.45 1-1s-.45-1-1-1h-2c-.55 0-1 .45-1 1s.45 1 1 1zM11 2v2c0 .55.45 1 1 1s1-.45 1-1V2c0-.55-.45-1-1-1s-1 .45-1 1zm0 18v2c0 .55.45 1 1 1s1-.45 1-1v-2c0-.55-.45-1-1-1s-1 .45-1 1zM5.99 4.58a.996.996 0 0 0-1.41 0 .996.996 0 0 0 0 1.41l1.06 1.06c.39.39 1.03.39 1.41 0s.39-1.03 0-1.41L5.99 4.58zm12.37 12.37a.996.996 0 0 0-1.41 0 .996.996 0 0 0 0 1.41l1.06 1.06c.39.39 1.03.39 1.41 0s.39-1.03 0-1.41l-1.06-1.06zm1.06-12.37a.996.996 0 0 0-1.41 0l-1.06 1.06c-.39.39-.39 1.03 0 1.41s1.03.39 1.41 0l1.06-1.06c.38-.38.38-1.02 0-1.41zM7.05 18.01a.996.996 0 0 0-1.41 0l-1.06 1.06c-.39.39-.39 1.03 0 1.41s1.03.39 1.41 0l1.06-1.06c.39-.39.39-1.03 0-1.41z"/>`;
    } else {
        document.body.className = "min-h-screen flex items-center justify-center antialiased p-6 relative overflow-hidden select-none bg-[#f4f4f6]";
        mainCard.className = "w-full max-w-5xl bg-white/70 backdrop-blur-3xl rounded-[32px] p-12 shadow-[0_30px_80px_rgba(0,0,0,0.02)] border border-white/60 grid grid-cols-1 md:grid-cols-5 gap-16 relative z-10 transition-all duration-500";
        themeIcon.innerHTML = `<path d="M12 3c-4.97 0-9 4.03-9 9s4.03 9 9 9 9-4.03 9-9c0-.46-.04-.92-.1-1.36-.57.83-1.53 1.36-2.61 1.36-1.77 0-3.21-1.44-3.21-3.21 0-1.08.53-2.04 1.36-2.61A8.932 8.932 0 0 0 12 3z"/>`;
    }
    // Synchronize current active tasks styles
    renderTasks();
}

themeToggleBtn.addEventListener('click', () => {
    currentTheme = (currentTheme === 'light') ? 'dark' : 'light';
    localStorage.setItem('theme-mode', currentTheme);
    applyTheme(currentTheme);
});
// Execute check on startup
applyTheme(currentTheme);


// Audio Infrastructure Assets
const tracks = [
    new Audio('https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3'),
    new Audio('https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3')
];
let isAudioPlaying = false;
tracks.forEach((track, i) => { track.loop = true; track.volume = sliders[i].value / 100; });

const focusRadioStation = new Audio('https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3');
focusRadioStation.loop = true;
focusRadioStation.volume = radioSlider.value / 100;
let isRadioPlaying = false;

radioPlayBtn.addEventListener('click', () => {
    if (isRadioPlaying) {
        focusRadioStation.pause(); isRadioPlaying = false;
        radioIcon.innerHTML = `<path d="M8 5v14l11-7z"/>`;
        radioPlayBtn.className = "w-12 h-12 rounded-full bg-[#0071e3] text-white flex items-center justify-center hover:bg-[#0077ed] transition-all active:scale-[0.93] shadow-md";
    } else {
        focusRadioStation.play()
            .then(() => {
                isRadioPlaying = true;
                radioIcon.innerHTML = `<path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/>`;
                radioPlayBtn.className = "w-12 h-12 rounded-full bg-[#1d1d1f] dark:bg-white text-white dark:text-black flex items-center justify-center hover:bg-black transition-all active:scale-[0.93] shadow-md";
            })
            .catch(() => alert("Click inside the dashboard frame once first, then play!"));
    }
});

radioSlider.addEventListener('input', (e) => {
    const value = e.target.value; radioVolVal.textContent = `${value}%`; focusRadioStation.volume = value / 100;
});

// --- AMBIENT CANVAS BACKGROUND ORBS ---
const canvas = document.getElementById('ambient-canvas');
const ctx = canvas.getContext('2d');
let particles = [];

function resizeCanvas() { canvas.width = window.innerWidth; canvas.height = window.innerHeight; }
window.addEventListener('resize', resizeCanvas);
resizeCanvas();

class DesignOrb {
    constructor() {
        this.x = Math.random() * canvas.width; this.y = Math.random() * canvas.height;
        this.size = Math.random() * 150 + 100; this.speedX = Math.random() * 0.6 - 0.3; this.speedY = Math.random() * 0.6 - 0.3;
    }
    update() {
        const pace = isTimerRunning ? 2.0 : 1.0; this.x += this.speedX * pace; this.y += this.speedY * pace;
        if (this.x < -this.size) this.x = canvas.width + this.size; if (this.x > canvas.width + this.size) this.x = -this.size;
        if (this.y < -this.size) this.y = canvas.height + this.size; if (this.y > canvas.height + this.size) this.y = -this.size;
    }
    draw() {
        let gradient = ctx.createRadialGradient(this.x, this.y, 2, this.x, this.y, this.size);
        // Canvas adjustments matching dark/light look
        if (currentTheme === 'dark') {
            gradient.addColorStop(0, 'rgba(0, 113, 227, 0.2)'); gradient.addColorStop(0.5, 'rgba(0, 113, 227, 0.03)');
        } else {
            gradient.addColorStop(0, 'rgba(0, 113, 227, 0.12)'); gradient.addColorStop(0.4, 'rgba(0, 113, 227, 0.03)');
        }
        gradient.addColorStop(1, 'rgba(255, 255, 255, 0)');
        ctx.fillStyle = gradient; ctx.beginPath(); ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2); ctx.fill();
    }
}
function initEngine() { particles = []; for (let i = 0; i < 20; i++) { particles.push(new DesignOrb()); } }
initEngine();
function animationLoop() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (currentTheme === 'dark') ctx.strokeStyle = 'rgba(255, 255, 255, 0.03)'; else ctx.strokeStyle = 'rgba(0, 113, 227, 0.06)';
    ctx.lineWidth = 1; ctx.beginPath();
    ctx.arc(canvas.width * 0.15, canvas.height * 0.25, 200, 0, Math.PI * 2); ctx.arc(canvas.width * 0.85, canvas.height * 0.75, 300, 0, Math.PI * 2); ctx.stroke();
    particles.forEach(p => { p.update(); p.draw(); }); requestAnimationFrame(animationLoop);
}
animationLoop();

// --- AMBIENT TEXTURE MIXERS ---
function toggleAudioEngine() {
    if (isAudioPlaying) {
        tracks.forEach(t => t.pause()); audioMasterBtn.textContent = 'Play Textures';
        audioMasterBtn.className = "bg-black/[0.04] dark:bg-white/[0.08] text-[#1d1d1f] dark:text-white text-xs font-medium px-4 py-2 rounded-full hover:bg-black/[0.08] dark:hover:bg-white/[0.12] transition-all"; isAudioPlaying = false;
    } else {
        isAudioPlaying = true; audioMasterBtn.textContent = 'Pause Textures';
        audioMasterBtn.className = "bg-[#1d1d1f] dark:bg-white text-white dark:text-black text-xs font-medium px-4 py-2 rounded-full hover:bg-black dark:hover:bg-gray-200 transition-all";
        sliders.forEach((slider, idx) => { if (slider.value > 0) tracks[idx].play().catch(() => {}); });
    }
}
sliders.forEach((slider, i) => {
    slider.addEventListener('input', (e) => {
        const val = e.target.value; volLabels[i].textContent = `${val}%`; tracks[i].volume = val / 100;
        if (isAudioPlaying && val > 0 && tracks[i].paused) tracks[i].play().catch(() => {}); else if (val == 0) tracks[i].pause();
    });
});
audioMasterBtn.addEventListener('click', toggleAudioEngine);

// --- TIMER LOOPS ---
function formatDisplayStats() {
    const hrs = Math.floor(totalSecondsStudied / 3600); const mins = Math.floor((totalSecondsStudied % 3600) / 60);
    totalStats.textContent = `Total: ${hrs}h ${String(mins).padStart(2, '0')}m`; streakContainer.innerHTML = '';
    for(let i=0; i < Math.min(completedSessionsCount, 6); i++) {
        const dot = document.createElement('div'); dot.className = "w-2 h-2 rounded-full bg-[#0071e3]"; streakContainer.appendChild(dot);
    }
}
function updateTimerFace() {
    const m = Math.floor(timeLeft / 60); const s = timeLeft % 60;
    timeDisplay.textContent = `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}
function clockTick() {
    if (timeLeft > 0) {
        timeLeft--; if (currentMode === 'focus') { totalSecondsStudied++; if (timeLeft % 10 === 0) { localStorage.setItem('secondsStudied', totalSecondsStudied); formatDisplayStats(); } } updateTimerFace();
    } else {
        clearInterval(timerInterval); isTimerRunning = false; startBtn.textContent = 'Start Focus';
        if (currentMode === 'focus') { completedSessionsCount++; localStorage.setItem('sessionsCount', completedSessionsCount); currentMode = 'break'; timeLeft = 5 * 60; pomoStatusText.textContent = "Recovery Break"; }
        else { currentMode = 'focus'; timeLeft = 25 * 60; pomoStatusText.textContent = "Focus Block"; } updateTimerFace(); formatDisplayStats();
    }
}
startBtn.addEventListener('click', () => {
    if (isTimerRunning) { clearInterval(timerInterval); isTimerRunning = false; startBtn.textContent = 'Start Focus'; }
    else { isTimerRunning = true; startBtn.textContent = 'Pause Clock'; timerInterval = setInterval(clockTick, 1000); }
});
resetBtn.addEventListener('click', () => {
    clearInterval(timerInterval); isTimerRunning = false; currentMode = 'focus'; timeLeft = 25 * 60; pomoStatusText.textContent = "Focus Block"; startBtn.textContent = 'Start Focus'; updateTimerFace();
});
clearStatsBtn.addEventListener('click', () => { localStorage.clear(); totalSecondsStudied = 0; completedSessionsCount = 0; formatDisplayStats(); });

// --- TASKS MODULE ---
function renderTasks() {
    todoList.innerHTML = ''; let activeCount = 0;
    tasks.forEach((task, index) => {
        if (!task.done) activeCount++; const li = document.createElement('li');
        li.className = currentTheme === 'dark' 
            ? "flex items-center justify-between p-3 bg-black/40 rounded-xl border border-white/5 group"
            : "flex items-center justify-between p-3 bg-white/80 rounded-xl border border-black/[0.04] group";
        li.innerHTML = `
            <div class="flex items-center gap-3 flex-1 cursor-pointer">
                <div class="w-4 h-4 rounded-full border ${currentTheme==='dark' ? 'border-white/20' : 'border-black/20'} flex items-center justify-center bg-transparent ${task.done ? 'bg-[#34c759] border-transparent' : ''}">${task.done ? '<span class="text-white text-[10px]">✓</span>' : ''}</div>
                <span class="text-sm ${task.done ? 'line-through text-[#86868b]' : (currentTheme==='dark'?'text-white':'text-[#1d1d1f]')}">${task.text}</span>
            </div>
            <button class="text-xs text-[#86868b] opacity-0 group-hover:opacity-100 hover:text-[#ff3b30] transition-all">Remove</button>
        `;
        li.querySelector('.flex-1').addEventListener('click', () => { tasks[index].done = !tasks[index].done; saveAndRenderTasks(); });
        li.querySelector('button').addEventListener('click', () => { tasks.splice(index, 1); saveAndRenderTasks(); }); todoList.appendChild(li);
    });
    todoCounter.textContent = `${activeCount} active`;
}
function saveAndRenderTasks() { localStorage.setItem('todoTasks', JSON.stringify(tasks)); renderTasks(); }
addTodoBtn.addEventListener('click', () => { if (todoInput.value.trim() === '') return; tasks.push({ text: todoInput.value.trim(), done: false }); todoInput.value = ''; saveAndRenderTasks(); });
todoInput.addEventListener('keypress', (e) => { if (e.key === 'Enter') addTodoBtn.click(); });

updateTimerFace(); formatDisplayStats(); renderTasks();